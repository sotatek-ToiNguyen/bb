<?php
/**
 * Created by PhpStorm.
 * User: andy
 * Date: 13/07/2018
 * Time: 14:44
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Group_Control_Typography;


class Widget_TZ_Testimonials_Carousel extends Widget_Base {

	public function get_name() {
		return 'tz-testimonials-carousel';
	}

	public function get_title() {
		return esc_html__( 'Testimonials Carousel', 'dici-feature-pack' );
	}

	public function get_icon() {
		return 'tz-icon-chat-1';
	}

	public function get_categories() {
		return [ 'themes-zone-elements' ];
	}

	public function get_script_depends() {
		return [
			'owl-carousel',
			'owl-carousel-controller'
		];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'section_content',
			[
				'label' => esc_html__( 'Content', 'dici-feature-pack' ),
			]
		);

		$this->add_control(
			'testimonials',
			[
				'label' => esc_html__('Testimonials', 'dici-feature-pack'),
				'type' => Controls_Manager::REPEATER,
				'separator' => 'before',
				'default' => [
					[
						'client_name' => esc_html__('Customer #1', 'dici-feature-pack'),
						'credentials' => esc_html__('Developer, Themes Zone.', 'dici-feature-pack'),
						'testimonial_text' => esc_html__('I am testimonial text. Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'dici-feature-pack'),
					],
					[
						'client_name' => esc_html__('Customer #2', 'dici-feature-pack'),
						'credentials' => esc_html__('Lead Developer, Automattic Inc', 'dici-feature-pack'),
						'testimonial_text' => esc_html__('I am testimonial text. Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'dici-feature-pack'),
					],
					[
						'client_name' => esc_html__('Customer #3', 'dici-feature-pack'),
						'credentials' => esc_html__('Designer, Themes Zone.', 'dici-feature-pack'),
						'testimonial_text' => esc_html__('I am testimonial text. Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'dici-feature-pack'),
					],
				],
				'fields' => [
					[
						'name' => 'client_name',
						'label' => esc_html__('Name', 'dici-feature-pack'),
						'type' => Controls_Manager::TEXT,
						'default' => esc_html__('My client name', 'dici-feature-pack'),
						'description' => esc_html__('The client or customer name for the testimonial', 'dici-feature-pack'),
						'dynamic' => [
							'active' => true,
						],
					],
					[
						'name' => 'credentials',
						'label' => esc_html__('Client Details', 'dici-feature-pack'),
						'type' => Controls_Manager::TEXT,
						'description' => esc_html__('The details of the client/customer like company name, credential held, company URL etc. HTML accepted.', 'dici-feature-pack'),
						'dynamic' => [
							'active' => true,
						],
					],

					[
						'name' => 'client_image',
						'label' => esc_html__('Customer/Client Image', 'dici-feature-pack'),
						'type' => Controls_Manager::MEDIA,
						'default' => [
							'url' => Utils::get_placeholder_image_src(),
						],
						'label_block' => true,
						'dynamic' => [
							'active' => true,
						],
					],

					[
						'name' => 'testimonial_text',
						'label' => esc_html__('Testimonials Text', 'dici-feature-pack'),
						'type' => Controls_Manager::WYSIWYG,
						'description' => esc_html__('What your customer/client had to say', 'dici-feature-pack'),
						'show_label' => false,
						'dynamic' => [
							'active' => true,
						],
					],

				],
				'title_field' => '{{{ client_name }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style',
			[
				'label' => esc_html__( 'Carousel Options', 'dici-feature-pack' ),
				'tab' => Controls_Manager::TAB_SETTINGS,
			]
		);

		$this->add_control(
			'autoplay',
			[
				'label' => esc_html__( 'Autoplay?', 'dici-feature-pack' ),
				'type' => Controls_Manager::SWITCHER,
				'default' => 'no',
				'label_on' => esc_html__( 'Yes', 'dici-feature-pack' ),
				'label_off' => esc_html__( 'No', 'dici-feature-pack' ),
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'show_arrows',
			[
				'label' => esc_html__( 'Show Arrows?', 'dici-feature-pack' ),
				'type' => Controls_Manager::SWITCHER,
				'default' => 'no',
				'label_on' => esc_html__( 'Yes', 'dici-feature-pack' ),
				'label_off' => esc_html__( 'No', 'dici-feature-pack' ),
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'show_dots',
			[
				'label' => esc_html__( 'Show Dots?', 'dici-feature-pack' ),
				'type' => Controls_Manager::SWITCHER,
				'default' => 'no',
				'label_on' => esc_html__( 'Yes', 'dici-feature-pack' ),
				'label_off' => esc_html__( 'No', 'dici-feature-pack' ),
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'gap',
			[
				'label' => esc_html__( 'Gap between items', 'dici-feature-pack' ),
				'type' => Controls_Manager::NUMBER,
				'default' => '30',
			]
		);

		$this->add_control(
			'speed',
			[
				'label' => esc_html__( 'Transition speed', 'dici-feature-pack' ),
				'type' => Controls_Manager::NUMBER,
				'default' => '500',
			]
		);

		$this->add_control(
			'autoplay_speed',
			[
				'label' => esc_html__( 'Autoplay speed in ms', 'dici-feature-pack'),
				'type' => Controls_Manager::NUMBER,
				'default' => 3000,
			]
		);

		$this->add_control(
			'loop',
			[
				'label' => esc_html__( 'Loop Items', 'dici-feature-pack' ),
				'type' => Controls_Manager::SWITCHER,
				'default' => 'no',
				'label_on' => esc_html__( 'Yes', 'dici-feature-pack' ),
				'label_off' => esc_html__( 'No', 'dici-feature-pack' ),
				'return_value' => 'yes',
			]
		);


		$this->add_control(
			'center',
			[
				'label' => esc_html__( 'Center Items?', 'dici-feature-pack' ),
				'type' => Controls_Manager::SWITCHER,
				'default' => 'no',
				'label_on' => esc_html__( 'Yes', 'dici-feature-pack' ),
				'label_off' => esc_html__( 'No', 'dici-feature-pack' ),
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'lazyload',
			[
				'label' => esc_html__( 'Use lazyload?', 'dici-feature-pack' ),
				'type' => Controls_Manager::SWITCHER,
				'default' => 'no',
				'label_on' => esc_html__( 'Yes', 'dici-feature-pack' ),
				'label_off' => esc_html__( 'No', 'dici-feature-pack' ),
				'return_value' => 'yes',
			]
		);



		$this->end_controls_section();

		$this->start_controls_section(
			'section_responsive',
			[
				'label' => esc_html__('Responsive Options', 'dici-feature-pack'),
				'tab' => Controls_Manager::TAB_SETTINGS,
			]
		);

		$this->add_control(
			'heading_desktop',
			[
				'label' => esc_html__( 'Desktop', 'dici-feature-pack' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'after',
			]
		);



		$this->add_control(
			'gutter',
			[
				'label' => esc_html__('Gutter', 'dici-feature-pack'),
				'description' => esc_html__('Space between columns.', 'dici-feature-pack'),
				'type' => Controls_Manager::NUMBER,
				'default' => 0,
				'selectors' => [
					'{{WRAPPER}} .tz-posts-carousel .tz-posts-carousel-item' => 'grid-gap: {{VALUE}}px;',
				],
			]
		);

		$this->add_control(
			'display_columns',
			[
				'label' => esc_html__('Columns per row', 'dici-feature-pack'),
				'type' => Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 2,
				'step' => 1,
				'default' => 1,
			]
		);


		$this->add_control(
			'scroll_columns',
			[
				'label' => esc_html__('Columns to scroll', 'dici-feature-pack'),
				'type' => Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 2,
				'step' => 1,
				'default' => 1,
			]
		);

		$this->add_control(
			'heading_tablet',
			[
				'label' => esc_html__( 'Tablet', 'dici-feature-pack' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'after',
			]
		);

		$this->add_control(
			'tablet_gutter',
			[
				'label' => esc_html__('Gutter', 'dici-feature-pack'),
				'description' => esc_html__('Space between columns.', 'dici-feature-pack'),
				'type' => Controls_Manager::NUMBER,
				'default' => 0,
				'selectors' => [
					'(tablet-){{WRAPPER}} .tz-posts-carousel .tz-posts-carousel-item' => 'grid-gap: {{VALUE}}px;',
				],
			]
		);


		$this->add_control(
			'tablet_display_columns',
			[
				'label' => esc_html__('Columns per row', 'dici-feature-pack'),
				'type' => Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 2,
				'step' => 1,
				'default' => 1,
			]
		);

		$this->add_control(
			'tablet_scroll_columns',
			[
				'label' => esc_html__('Columns to scroll', 'dici-feature-pack'),
				'type' => Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 2,
				'step' => 1,
				'default' => 1,
			]
		);

		$this->add_control(
			'heading_mobile',
			[
				'label' => esc_html__( 'Mobile', 'dici-feature-pack' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'after',
			]
		);

		$this->add_control(
			'mobile_gutter',
			[
				'label' => esc_html__('Gutter', 'dici-feature-pack'),
				'description' => esc_html__('Space between columns.', 'dici-feature-pack'),
				'type' => Controls_Manager::NUMBER,
				'default' => 0,
				'selectors' => [
					'(mobile-){{WRAPPER}} .tz-posts-carousel .tz-posts-carousel-item' => 'grid-gap: {{VALUE}}px;',
				],
			]
		);

		$this->add_control(
			'mobile_display_columns',
			[
				'label' => esc_html__('Columns per row', 'dici-feature-pack'),
				'type' => Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 2,
				'step' => 1,
				'default' => 1,
			]
		);

		$this->add_control(
			'mobile_scroll_columns',
			[
				'label' => esc_html__('Columns to scroll', 'dici-feature-pack'),
				'type' => Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 2,
				'step' => 1,
				'default' => 1,
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_styling',
			[
				'label' => esc_html__( 'Testimonial Content', 'dici-feature-pack'),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'content_align',
			[
				'label' => esc_html__('Alignment', 'dici-feature-pack'),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__('Left', 'dici-feature-pack'),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__('Center', 'dici-feature-pack'),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__('Right', 'dici-feature-pack'),
						'icon' => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__('Justified', 'dici-feature-pack'),
						'icon' => 'fa fa-align-justify',
					],
				],
				'default' => 'center',
			]
		);

		$this->add_responsive_control(
			'text_padding',
			[
				'label' => esc_html__('Text Padding', 'dici-feature-pack'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em'],
				'selectors' => [
					'{{WRAPPER}} .testimonial .testimonial-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'isLinked' => false,
			]
		);

		$this->add_control(
			'text_color',
			[
				'label' => esc_html__( 'Color', 'dici-feature-pack' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .testimonial .testimonial-text' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'text_border_color',
			[
				'label' => esc_html__( 'Border Color', 'dici-feature-pack' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .testimonial .testimonial-text, {{WRAPPER}} .testimonial .testimonial-text:after' => 'border-color: {{VALUE}};',
				],
			]
		);



		$this->add_control(
			'text_border_width',
			[
				'label' => esc_html__( 'Border Width', 'dici-feature-pack' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 5,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .testimonial .testimonial-text, {{WRAPPER}} .testimonial .testimonial-text:after' => 'border-width: {{SIZE}}{{UNIT}};',
				],
			]
		);


		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'text_typography',
				'selector' => '{{WRAPPER}} .testimonial .testimonial-text',
			]
		);

		$this->add_responsive_control(
			'item_text_bottom_space',
			[
				'label' => esc_html__( 'Spacing', 'dici-feature-pack' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .testimonial .testimonial-text' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);


		$this->end_controls_section();

		$this->start_controls_section(
			
			'section_testimonials_author_name',
			[
				'label' => esc_html__( 'Author Name', 'dici-feature-pack' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'author_name_tag',
			[
				'label' => esc_html__( 'Author HTML Tag', 'dici-feature-pack' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'h1' => esc_html__( 'H1', 'dici-feature-pack' ),
					'h2' => esc_html__( 'H2', 'dici-feature-pack' ),
					'h3' => esc_html__( 'H3', 'dici-feature-pack' ),
					'h4' => esc_html__( 'H4', 'dici-feature-pack' ),
					'h5' => esc_html__( 'H5', 'dici-feature-pack' ),
					'h6' => esc_html__( 'H6', 'dici-feature-pack' ),
					'div' => esc_html__( 'div', 'dici-feature-pack' ),
				],
				'default' => 'h4',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Color', 'dici-feature-pack' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .testimonial .testimonial-author-name' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'selector' => '{{WRAPPER}} .testimonial .testimonial-author-name',
			]
		);

		$this->add_responsive_control(
			'item_name_bottom_space',
			[
				'label' => esc_html__( 'Spacing', 'dici-feature-pack' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .testimonial .testimonial-author-name' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_testimonials_author_credentials',
			[
				'label' => esc_html__('Author Credentials', 'dici-feature-pack'),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'credential_color',
			[
				'label' => esc_html__( 'Color', 'dici-feature-pack' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .testimonial .testimonial-credentials' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'credential_typography',
				'selector' => '{{WRAPPER}} .testimonial .testimonial-credentials',
			]
		);


		$this->end_controls_section();

	}

	protected function render() {

		$settings = $this->get_settings();

		$carousel_settings = array();

		$carousel_settings['selector']       = ".tz-testimonials-carousel";
		$carousel_settings['type']           = "content-carousel";
		$carousel_settings['slides']         = isset( $settings['cols'] ) ? $settings['cols'] : '1';
		$carousel_settings['scroll']         = isset( $settings['scroll'] ) ? $settings['scroll'] : '1';
		$carousel_settings['custom_nav']     = isset( $settings['show_arrows'] ) ? $settings['show_arrows'] : 'no' ;
		$carousel_settings['dots']           = isset( $settings['show_dots'] ) ?  $settings['show_dots'] : 'yes';
		$carousel_settings['autoplay']       = isset( $settings['autoplay'] ) ?  $settings['autoplay'] : 'yes';
		$carousel_settings['gap']            = isset( $settings['gap'] ) ? $settings['gap'] : '0';
		$carousel_settings['speed']          = isset( $settings['speed'] ) ? $settings['speed'] : '500' ;
		$carousel_settings['autoplay_speed'] = isset( $settings['autoplay_speed'] ) ? $settings['autoplay_speed'] : '3000' ;
		$carousel_settings['loop']           = isset( $settings['loop'] ) ? $settings['loop'] : 'yes';
		$carousel_settings['center']         = isset( $settings['center'] ) ? $settings['center'] : 'no';
		$carousel_settings['lazyload']       = isset( $settings['lazyload'] ) ? $settings['lazyload'] : 'no';
		$carousel_settings['pause_on_hover'] = isset( $settings['pause_on_hover'] ) ? $settings['pause_on_hover'] : 'no';


		$responsive_settings = [
			'slides_desktop' => $settings['display_columns'],
			'scroll_desktop' => $settings['scroll_columns'],
			'gap_desktop' => $settings['gutter'],
			'slides_tablet' => $settings['tablet_display_columns'],
			'scroll_tablet' => $settings['tablet_scroll_columns'],
			'gap_tablet' => $settings['tablet_gutter'],
			'slides_mobile' => $settings['mobile_display_columns'],
			'scroll_mobile' => $settings['mobile_scroll_columns'],
			'gap_mobile' => $settings['mobile_gutter'],
		];

		$carousel_settings = array_merge($carousel_settings, $responsive_settings);

		$carousel_settings = apply_filters( '/elementor/tz_testimonials_carousel_settigns', $carousel_settings );

		$args[ 'carousel_settings' ] = wp_json_encode($carousel_settings);

		$args[ 'cols' ] = $settings['display_columns'];

		$args[ 'testimonials' ] = $settings['testimonials'];

		$args['author_name_tag'] = $settings['author_name_tag'];

		$args['content_align'] = $settings['content_align'];

		TZ_Helper::get_template('widget-testimonials-carousel.php', $args);

	}

}